<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="{{ route('dashboard') }}">
                <i class="mdi mdi-desktop-mac menu-icon"></i>
                <span class="menu-title">INICIO</span>
            </a>
        </li>
        <!-- <li class="nav-item">
            <a class="nav-link" href="#">
                <i class="mdi mdi-application menu-icon"></i>
                <span class="menu-title">APP</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">
                <i class="mdi mdi-application menu-icon"></i>
                <span class="menu-title">APP</span>
            </a>
        </li> -->
        <li class="nav-item">
            <a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                <i class="menu-icon mdi mdi-power"></i>
                <span class="menu-title">{{ __('Cerrar sesión') }}</span>

            </a>

            <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                @csrf
            </form>
        </li>
    </ul>
</nav>