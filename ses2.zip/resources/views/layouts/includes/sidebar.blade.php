<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item nav-category">
            @if (Auth::user()->role === 1)
            {{ __('Administrador') }}
            @endif
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#">
                <i class="menu-icon mdi mdi-account-circle"></i>
                <span class="menu-title">{{ Auth::user()->username }}</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="{{ route('dashboard') }}">
                <i class="mdi mdi-desktop-mac menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item nav-category">Menu</li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#customers" aria-expanded="false" aria-controls="customers">
                <i class="menu-icon mdi mdi-account-multiple"></i>
                <span class="menu-title">Clientes</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="customers">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-human-male"></i>  -->Prospectos
                        </a></li>
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-human-handsup"></i>  -->Clientes
                        </a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="">
                <i class="menu-icon mdi mdi-truck"></i>
                <span class="menu-title">Proveedores</span>
            </a>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#products" aria-expanded="false" aria-controls="products">
                <i class="menu-icon mdi mdi-package-variant-closed"></i>
                <span class="menu-title">Productos</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="products">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"><a class="nav-link" href="">
                            <!-- <i class="mdi mdi-package-variant-closed"></i>  -->Productos
                        </a></li>
                    <li class="nav-item"><a class="nav-link" href="">
                            <!-- <i class="mdi mdi-view-list"></i>  -->Categorias
                        </a></li>
                    <li class="nav-item"><a class="nav-link" href="">
                            <!-- <i class="mdi mdi-package-variant"></i>  -->Kits
                        </a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#purchases" aria-expanded="false" aria-controls="purchases">
                <i class="menu-icon mdi mdi-cart"></i>
                <span class="menu-title">Compras</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="purchases">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-cart-plus"></i>  -->Pedidos
                        </a></li>
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-cart"></i>  -->Compras
                        </a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#sales" aria-expanded="false" aria-controls="sales">
                <i class="menu-icon mdi mdi-cash-usd"></i>
                <span class="menu-title">Ventas</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="sales">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-square-inc-cash"></i>  -->Cotizaciones
                        </a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#Settings" aria-expanded="false" aria-controls="Settings">
                <i class="menu-icon mdi mdi-settings"></i>
                <span class="menu-title">Configuración</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="Settings">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-factory"></i>  -->Empresa
                        </a></li>
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-account-multiple"></i>  -->Usuarios
                        </a></li>
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-lock-outline"></i>  -->Roles
                        </a></li>
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-package"></i>  -->Modulos
                        </a></li>
                    <li class="nav-item"> <a class="nav-link" href="">
                            <!-- <i class="mdi mdi-vector-combine"></i>  -->Tipo proyecto
                        </a></li>
                </ul>
            </div>
        </li>
        <li class="nav-item">
            <a class="nav-link" data-bs-toggle="collapse" href="#logout" aria-expanded="false" aria-controls="logout">
                <i class="menu-icon mdi mdi-power"></i>
                <span class="menu-title">Salir</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="logout">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item">
                        <a class="nav-link" href="{{ route('logout') }}" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                            <i class="dropdown-item-icon mdi mdi-logout text-primary me-2"></i>
                            {{ __('Cerrar sesión') }}
                        </a>

                        <form id="logout-form" action="{{ route('logout') }}" method="POST" class="d-none">
                            @csrf
                        </form>
                    </li>
                </ul>
            </div>
        </li>
    </ul>
</nav>