@extends('layouts.app')

@section('content')

@include('layouts.includes.sidebarHome')

<div class="main-panel">
    <div class="content-wrapper">
        <div class="row">
            <div class="col-md-12">
            </div>
        </div>
    </div>
    @include('layouts.includes.footer')
</div>
@endsection