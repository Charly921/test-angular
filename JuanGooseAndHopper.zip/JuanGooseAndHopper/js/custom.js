$(document).ready(function () {
   new WOW({
       mobile: false,
   }).init();
});